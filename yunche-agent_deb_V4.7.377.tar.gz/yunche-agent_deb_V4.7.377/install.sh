#!/bin/bash
#
# Copyright (c) 2022 Nan.Xing
#

project_name=`ls |grep agent |awk '{print $0}'`
project_daemon="/usr/bin/yunche-daemon"

# 禁止修改端口
serverAddr="192.168.2.200:8888"
# 禁止修改端口
rasAddr="192.168.2.201:8081"
# 抓包开关，0-关闭，1-开启
capture="1"

usage() {
 echo "Usage:  $0 [install|remove]"
 exit 1
}

#检查程序是否安装
is_installed(){
 rpms=`dpkg -l|grep agent_v* |awk '{print $0}'`
 #如果不存在返回1，存在返回0
 if [ -z "${rpms}" ]; then
 return 1
 else
 return 0
 fi
}

#安装
install(){
 is_installed
 if [ $? -eq "0" ]; then
    echo "Yunche Agent 已安装. 安装包名称： ${rpms}."
 else
    echo "Yunche Agent 安装..."
    dpkg -i "${project_name}"
    # 初始化
    if [ ! -f "${project_daemon}" ]; then
     echo "请检查Yunche Agent是否安装成功，检查文件 ${project_daemon}"
     exit 0
    fi
    # shellcheck disable=SC2016
    ${project_daemon} install -text '{"Account": "admin","Password": "123456","runmode": "prod","pushServer": "true","serverAddr": "'${serverAddr}'","rasAddr": "'${rasAddr}'","capture":"'${capture}'"}'
    ${project_daemon} start
 fi
 #exit 0
}

#卸载
remove(){
 is_installed
 if [ $? -eq "0" ]; then
  echo "Yunche Agent 卸载.... "
  ${project_daemon} stop
  dpkg -r "${rpms}"
 else
  echo "Yunche Agent 未安装。"
 fi
 #exit 0
}

#根据输入参数，选择执行对应方法，不输入则执行使用说明
case "$1" in
 "install")
 install
 ;;
 "remove")
 remove
 ;;
 *)
 usage
 ;;
esac
